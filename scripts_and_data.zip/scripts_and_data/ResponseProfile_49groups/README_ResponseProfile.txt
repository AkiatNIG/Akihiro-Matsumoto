1. System requirements
The codes are available on Matlab (2017b or later).
All the codes were tested on the above systems.
Those codes do not need non-standard hardware.

2. Installation guide
Copy the codes on the basic Matlab path on your system. And load dsets_ResponseMeasures.mat, dataset of response profiles for the 49 groups, on Workspace. Add path where you set dsets_ResponseMeasures.mat in the script (Line 11: replace "xxx" in "cd0='xxx'" by your path).
Then run the scripts with setting group ID ("displaying_each_group(6), for showing Group6"). There are instructions on the header parts of the individual scripts.

Typical install time on a "normal" desktop computer would be ~5-10 seconds.

3. Demo
3-1. copy dsets_ResponseMeasures.mat
3-2. copy the path to dsets_ResponseMeasures.mat on displaing_each_group (Line11)
3-3. run displaying_each_group(6) on your Workspace 

Typical install time on a "normal" desktop computer would be ~5-10 seconds.

4. Outputs
This shows GABA signal, ON response index, OFF response index, Bi-response index, Transience index, Latency index, and RF size, with colored plots (gray denotes responses of others).