function [outputArg1,outputArg2] = untitled(g_id)
%UNTITLED Summary of this function goes here
%   displaying response profiles of 49 groups. 
%   g_id: please set group number that you want to display. e.g.,
%   displaying_each_group(6), for showing Group6.
%   Outputs: you can find: GABA signal, ON response index, OFF response index, 
%   Bi-response index, Transience index, Latency index, and RF size histogram 

col=flipud(colormap(jet(49)));
close all;
cd0='xxx';%Please add directory where you set "dsets_ResponseMeasures.mat"
%
cd(cd0);
load('dsets_ResponseMeasures.mat');
dsets=eval('dsets');
%
grp_id=dsets{g_id+1,1};
r_on=dsets{g_id+1,2};
r_off=dsets{g_id+1,3};
r_bir=dsets{g_id+1,4};
r_tran=dsets{g_id+1,5};
r_lat=dsets{g_id+1,6};
df=dsets{g_id+1,7};
rf=dsets{g_id+1,8};
%
for i=2:length(dsets(:,1));
    if i==2;
        p1=dsets{i,2};
        p2=dsets{i,3};
        p3=dsets{i,4};
        p4=dsets{i,5};
        p5=dsets{i,6};
        %
        mdf=dsets{i,7};
        mrf=dsets{i,8}(2,:);
        %
    else
        p1=[p1;dsets{i,2}];
        p2=[p2;dsets{i,3}];
        p3=[p3;dsets{i,4}];
        p4=[p4;dsets{i,5}];
        p5=[p5;dsets{i,6}];
        %
        mdf=[mdf;dsets{i,7}];
        mrf=[mrf;dsets{i,8}(2,:)];
    end
end
%
%%
figure('position',[150,300,640,300]);
subplot(3,5,[1,5]);
plot(df(1,:)+df(2,:),'-','linewidth',1,'color',[0.65,0.65,0.65]);hold on
plot(df(1,:)-df(2,:),'-','linewidth',1,'color',[0.65,0.65,0.65]);
plot(df(1,:),'-','linewidth',1.2,'color',col(g_id,:));
set(gca,'box','off');
set(gca,'tickdir','out');
set(gca,'xtick',[]);
axis([-10,750,-0.4,1.4]);
tit=['Group#',num2str(g_id)];
title(tit,'fontsize',9);
set(gca,'fontsize',9);
%
subplot(3,5,6);
for i=1:49;
    plot(1,p1(i),'o','linewidth',0.8,'markeredgecolor',[0.65,0.65,0.65]);hold on
end
plot(1,r_on,'o','linewidth',1.2,'markeredgecolor',col(g_id,:));
set(gca,'box','off');
set(gca,'tickdir','out');
set(gca,'xtick',[]);
ylabel('ON resp');
axis([0.7,1.3,0,1]);
set(gca,'fontsize',9);
%
subplot(3,5,7);
for i=1:49;
    plot(1,p2(i),'o','linewidth',0.8,'markeredgecolor',[0.65,0.65,0.65]);hold on
end
plot(1,r_off,'o','linewidth',1.2,'markeredgecolor',col(g_id,:));
set(gca,'box','off');
set(gca,'tickdir','out');
set(gca,'xtick',[]);
ylabel('OFF resp');
axis([0.7,1.3,0,1]);
set(gca,'fontsize',9);
%
subplot(3,5,8);
for i=1:49;
    plot(1,p3(i),'o','linewidth',0.8,'markeredgecolor',[0.65,0.65,0.65]);hold on
end
plot(1,r_bir,'o','linewidth',1.2,'markeredgecolor',col(g_id,:));
set(gca,'box','off');
set(gca,'tickdir','out');
set(gca,'xtick',[]);
ylabel('Bi-resp');
axis([0.7,1.3,0,1]);
set(gca,'fontsize',9);
%
subplot(3,5,9);
for i=1:49;
    plot(1,p4(i),'o','linewidth',0.8,'markeredgecolor',[0.65,0.65,0.65]);hold on
end
plot(1,r_tran,'o','linewidth',1.2,'markeredgecolor',col(g_id,:));
set(gca,'box','off');
set(gca,'tickdir','out');
set(gca,'xtick',[]);
ylabel('Trans');
axis([0.7,1.3,0,1]);
set(gca,'fontsize',9);
%
subplot(3,5,10);
for i=1:49;
    plot(1,p5(i),'o','linewidth',0.8,'markeredgecolor',[0.65,0.65,0.65]);hold on
end
plot(1,r_lat,'o','linewidth',1.2,'markeredgecolor',col(g_id,:));
set(gca,'box','off');
set(gca,'tickdir','out');
set(gca,'xtick',[]);
ylabel('Latency');
axis([0.7,1.3,0,1]);
set(gca,'fontsize',9);
%
subplot(3,5,[11,12]);
h0=mean(mrf,1);
bar(rf(1,:),h0/max(h0),'barwidth',1,'edgecolor','none','facecolor',[0.5,0.5,0.5]);hold on
bar(rf(1,:),rf(2,:)/max(rf(2,:)),'barwidth',1,'edgecolor','none','facecolor',col(g_id,:));hold on
set(gca,'box','off');
set(gca,'tickdir','out');
ylabel('Fraction');
xlabel('RF size [um]');
set(gca,'fontsize',9);


% outputArg1 = inputArg1;
% outputArg2 = inputArg2;
end

