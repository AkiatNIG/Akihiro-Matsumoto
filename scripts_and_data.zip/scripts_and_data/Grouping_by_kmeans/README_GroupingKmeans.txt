1. System requirements
The codes are available on Matlab (2017b or later).
All the codes were tested on the above systems.
Those codes do not need non-standard hardware.

2. Installation guide
Copy all the codes (grouping_data_intoN; perform_kmeans_NN) on the basic Matlab path on your system. And copy demo dataset "rf_ori.mat", dataset of RF orientation bias and GABA signal group ID, on your Workspace. Add copy the path where you set rf_ori.mat in the script (Line 13: replace "xxx" in "cd0='xxx'" by your path).
Then run the scripts with a number of clusters (e.g. "grouping_data_intoN(5), for clustering to 5 groups"). There are instructions on the header parts of the individual scripts.

Typical install time on a "normal" desktop computer would be ~20-60 seconds.

3. Demo
3-1. copy rf_ori.mat
3-2. copy the path to rf_ori.mat on grouping_data_intoN (Line13)
3-3. run grouping_data_intoN(3) on your Workspace

This demonstrates clustering datasets into 3 groups. 

Typical install time on a "normal" desktop computer would be ~20-60 seconds.

4. Outputs
There are 3 outputs:
Figure 1: results of kmeans (by "n_forK" cluster number).
Figure 2: Histogram for each cluster (color-coded)
Figure 3: Population of each cluster for individual GABA signal group (color-coded, as in Figure 3).
All data in the outputs are saved in your current directory (group_hist.m; group_label.m; group_population)
 