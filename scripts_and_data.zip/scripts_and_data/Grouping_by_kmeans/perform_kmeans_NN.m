function [outputArg1,outputArg2] = untitled(inp, reps, distP)
%UNTITLED Summary of this function goes here
%   reps: to decide the number of clusters


%
close all;
%
dist9={'sqeuclidean';'cityblock';'cosine';'correlation'};
%
str=cell(length(reps),3);
for i=1:length(reps);
    ad=reps(i);
    [idx,C]=kmeans(inp,ad,'Distance',dist9{distP},'Display','final','MaxIter',10000,'Replicates',20);
    %
    [silh,h]=silhouette(inp,idx,dist9{distP});
    %
    str{i,1}=ad;
    str{i,2}=silh;
    str{i,3}=h;
    str{i,4}=mean(silh);
    str{i,5}=min(silh);
    str{i,6}=idx;
    str{i,7}=C;
    %
    if i==1;
        sc9=[ad,mean(silh)];
    else
        sc9=[sc9;[ad,mean(silh)]];
    end        
end
%
[val,ad]=max(sc9(:,2));
ad=reps(ad);
yom=cell(1,1);
[idx,C]=kmeans(inp,ad,'Distance',dist9{distP},'Display','iter','Replicates',5);
%
close all;
figure('position',[150,300,300,300]);
for i=1:ad;
    fid=find(idx==i);
    temp=inp(fid,:);
    if length(temp(1,:))==1;
        plot(i,temp,'o');hold on
    else
        plot(temp(:,1),temp(:,2),'.');hold on
        plot(C(i,1),C(i,2),'kx');
    end
    yom{i,1}=fid;
    yom{i,2}=temp;
    %
end
set(gca,'box','off');
set(gca,'tickdir','out');
set(gca,'fontsize',9);
xlabel('group#')
%
%%
str2=cell(1,1);
str2{1,1}=str;
str2{2,1}=yom;
%



    
    


outputArg1 = str2;
end

