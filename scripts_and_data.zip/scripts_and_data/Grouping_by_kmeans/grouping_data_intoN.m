function [outputArg1,outputArg2] = untitled2(n_forK)
%UNTITLED2 Summary of this function goes here
%   Grouping data into a given clustering numbers ("n_forK").
%   Demo dataset, "rf_ori" includes RF orientation bias index (column1) and
%   GABA signal groupID (column2)
%   set a number for clusters, "n_forK". 
%   Outputs: Figure1, results of Kmeans by n_forK cluster number. Figure2,
%   Histogram for each cluster (color coded). Figure 3, Population of 
%   clusters for 49 groups.

close all;
%
cd0='xxx';%Please add directory where you set demo dataset "rf_ori.mat"
cd(cd0);
load('rf_ori');
rf_ori=eval('rf_ori');
%
qq=perform_kmeans_NN(rf_ori(:,1),n_forK,1);
%
t_gid=cell(1,1);
for i=1:length(qq{2,1}(:,1));
    t_gid{i,1}=qq{2,1}{i,1};
    t_gid{i,2}=qq{2,1}{i,2};
end
%
labs=[zeros(length(rf_ori(:,1)),1),rf_ori(:,2)];
for i=1:length(t_gid(:,1));
    gid0=t_gid{i,1};
    labs(gid0,1)=i;
end
%
group_hist=cell(1,1);
bin=[0:0.01:1];
figure('position',[150,300,360,180]);
for i=1:length(t_gid(:,1));
    h0=hist(t_gid{i,2},bin);
    bar(bin,h0/sum(h0));hold on
    %
    t_gid{i,3}=transpose([bin;h0]);
    group_hist{i,1}=['group#',num2str(i)];
    group_hist{i,2}=transpose([bin;h0]);
end
set(gca,'box','off');
set(gca,'tickdir','out');
set(gca,'fontsize',9);
ylabel('Fraction');
%
%%
%
for i=1:49;
    aid=labs(labs(:,2)==i,:);
    for j=1:n_forK;
        df0=find(aid(:,1)==j);
        if j==1;
            df9=length(df0);
        else
            df9=[df9,length(df0)];
        end
    end
    %
    if i==1;
        vals=df9;
    else
        vals=[vals;df9];
    end
end
% %
valsb=vals./sum(vals,2);
figure('position',[450,300,300,180]);
bar(valsb,'stack');
set(gca,'box','off');
set(gca,'tickdir','out');
set(gca,'fontsize',9);
set(gca,'xtick',[1,10,20,30,40,49]);
ylabel('Population');
% %%
group_label=labs(:,1);
group_population=vals;
save('group_label','group_label');
save('group_population','group_population');
save('group_hist','group_hist');
%     
% 
% 
%outputArg1 = outs;
%outputArg2 = inputArg2;
end

