1. System requirements
The codes are available on R (4.3.2) on Windows11.
All the codes were tested on the above systems.
Those codes do not need non-standard hardware.

2. Installation guide
Copy the codes on the basic path on your system. And load dataset of gene couts and metadata from Yan et al (2020). And rung R-code-for-dot-plots_12.11.2023.R on R(4.3.2).

3. Demo
3-1. run R-code-for-dot-plots_12.11.2023