    #Load required libraries 
library(scCustomize)
library(dplyr)
library(patchwork)
library(ggplot2)
library(tidyverse)
library(viridis)
library(qs)
library(ComplexHeatmap)

    #Set the working directory, load raw gene counts into R, and create a Seurat object 
setwd("/Users/morrisj/Desktop/Projects/Amacrine_Cells")
counts <- read.csv("GSE149715_MouseAC_count_matrix.csv", header=TRUE, row.names=1)
amacrine <- CreateSeuratObject(counts=counts)

    #Attach Sanes assigned cluster IDs to each cell 
clusterIDs <- read.csv("MouseAC_metafile.csv", header=TRUE)
Idents(object=amacrine) <- clusterIDs$Cluster 

    #Retain all clusters except AC16
Clusters_NoAC16 <- c("AC_1","AC_2","AC_3","AC_4","AC_5","AC_6","AC_7","AC_8","AC_9","AC_10","AC_11","AC_12","AC_13","AC_14","AC_15","AC_17","AC_18","AC_19","AC_20","AC_21","AC_22","AC_23","AC_24","AC_25","AC_26","AC_27","AC_28","AC_29","AC_30","AC_31","AC_32","AC_33","AC_34","AC_35","AC_36","AC_37","AC_38","AC_39","AC_40","AC_41","AC_42","AC_43","AC_44","AC_45","AC_46","AC_47","AC_48","AC_49","AC_50","AC_51","AC_52","AC_53","AC_54","AC_55","AC_56","AC_57","AC_58","AC_59","AC_60","AC_61","AC_62","AC_63")

amacrine_noAC16 <- subset(x=amacrine, idents=Clusters_NoAC16)

    #Normalize clusters
amacrine_noAC16 <- NormalizeData(amacrine_noAC16, normalization.method = "LogNormalize", scale.factor = 10000)
#[1] 27933 31885

    
    #Filter cells to retain those that intersect the below 3 categories
#1. GABA synthesizing cells : Gad1 (aka GAD67), Gad2 (aka GAD65)
amacrine_noAC16_GABA_synthesizing <- subset(x = amacrine_noAC16, Gad1 > 0.5 | Gad2 > 0.5)

#2. GABA releasing cells : Slc32a1 
amacrine_noAC16_GABA_releasing <- subset(x = amacrine_noAC16, Slc32a1 > 0.5)

#3. GABA responsive cells : GABA receptors : "Gabbr1", "Gabbr2", "Gabra1", "Gabra2", "Gabra3", "Gabra4", "Gabra5", "Gabrb1", "Gabrb2", "Gabrb3", "Gabrg1", "Gabrg2", "Gabrg3", "Gabrd", "Gabre", "Gabrq", "Gabrr1", "Gabrr2", "Gabrr3"
amacrine_noAC16_GABA_responsive <- subset(x = amacrine_noAC16, Gabbr1 > 0.5 | Gabbr2 > 0.5 | Gabra1 > 0.5 | Gabra2 > 0.5 | Gabra3 > 0.5 | Gabra4 > 0.5 | Gabra5 > 0.5 | Gabrb1 > 0.5 | Gabrb2 > 0.5 | Gabrb3 > 0.5 | Gabrg1 > 0.5 | Gabrg2 > 0.5 | Gabrg3 > 0.5 | Gabrd > 0.5 | Gabre > 0.5 | Gabrq > 0.5 | Gabrr1 > 0.5 | Gabrr2 > 0.5 | Gabrr3 > 0.5)

# Intersection of GABA_synthesizing, GABA_releasing, GABA_responsive 
common.cells.A <- intersect(colnames(amacrine_noAC16_GABA_synthesizing), colnames(amacrine_noAC16_GABA_releasing)) 
common.cells.B <- intersect(common.cells.A, colnames(amacrine_noAC16_GABA_responsive))
amacrine_noAC16[["CellName"]] <- colnames(amacrine_noAC16)
amacrine_GABAintersect <- subset(x = amacrine_noAC16, subset = CellName %in% common.cells.B)

    #Identify tetrodotoxin-sensitive clusters 
Nav_genes <- c("Scn1a","Scn3a","Scn4a","Scn8a","Scn9a")
RidgePlot(amacrine_GABAintersect, features=Nav_genes)
Nav_genes_filt <- c("Scn1a","Scn3a") #Based on RidgePlots #GABAintersect_NaV_RidgePlots.pdf
CDP_amacrine_GABAintersect <- Clustered_DotPlot(seurat_object=amacrine_GABAintersect, features=Nav_genes_filt, row_label_size=6, plot_km_elbow = FALSE, seed=42, column_label_size=4, legend_label_size=2, legend_title_size=4) #GABAintersect_NaV_ClusteredDotPlot.pdf

Clusters_ordered_amacrine_GABAintersect <- c("AC_3", "AC_46", "AC_7", "AC_2", "AC_36", "AC_30", "AC_39", "AC_25", "AC_32", "AC_31", "AC_60", "AC_54", "AC_21", "AC_63", "AC_40", "AC_50", "AC_15", "AC_44", "AC_45", "AC_53", "AC_52", "AC_57", "AC_59", "AC_10", "AC_29", "AC_61", "AC_1", "AC_24", "AC_48", "AC_12", "AC_42", "AC_51", "AC_20", "AC_27", "AC_41", "AC_47", "AC_13", "AC_37", "AC_56", "AC_5", "AC_58", "AC_14", "AC_43", "AC_11", "AC_38", "AC_62", "AC_49", "AC_35", "AC_9", "AC_6", "AC_55", "AC_4", "AC_28", "AC_18", "AC_26", "AC_22", "AC_23", "AC_34", "AC_17", "AC_19", "AC_33", "AC_8")
amacrine_GABAintersect@active.ident <- factor(amacrine_GABAintersect@active.ident, levels=Clusters_ordered_amacrine_GABAintersect)

DP_amacrine_GABAintersect_NaVfilt <- DotPlot(amacrine_GABAintersect, features = Nav_genes_filt, dot.scale=4, cols=c("yellow","blue")) + RotatedAxis() +theme(axis.text.x=element_text(size=6),axis.text.y=element_text(size=6),legend.key.size=unit(1,'cm'),legend.key.height=unit(0.5,'cm'),legend.key.width=unit(0.2,'cm'),legend.title=element_text(size=4),legend.text=element_text(size=4), axis.title=element_text(size=4)) #GABAintersect_NaV_DotPlot.pdf
DP_amacrine_GABAintersect_NaVfilt$data

    #Create a dot plot of genes of interest in NaV-expressing clusters (AchR, NMDAR, AMPA/KAR, GlycineR, and GABARs)
GenesofInterest_filt <- c("Scn1a", "Scn3a","Chrm1", "Chrm2", "Chrm3", "Chrm5", "Chrna1", "Chrna2", "Chrna3", "Chrna4", "Chrna5", "Chrna6", "Chrna7", "Chrnb1", "Chrnb2", "Chrnb3", "Chrnb4", "Grm1", "Grm2", "Grm3", "Grm4", "Grm5", "Grm6", "Grm7", "Grm8", "Gria1", "Gria2", "Gria3", "Gria4", "Grid1", "Grid2", "Grik1", "Grik2", "Grik3", "Grik4", "Grik5", "Grin1", "Grin2a", "Grin2b", "Grin2c", "Grin2d", "Grin3a", "Grin3b", "Glra1", "Glra2", "Glra3", "Glra4", "Glrb", "Gabbr1", "Gabbr2", "Gabra1", "Gabra2", "Gabra3", "Gabra4", "Gabra5", "Gabrb1", "Gabrb2", "Gabrb3", "Gabrg1", "Gabrg2", "Gabrg3", "Gabrd", "Gabre", "Gabrq", "Gabrr1", "Gabrr2", "Gabrr3")

GABAintersect_NaVClusters <- c("AC_3", "AC_46", "AC_7", "AC_2", "AC_36", "AC_30", "AC_39", "AC_25", "AC_32", "AC_31", "AC_60", "AC_54", "AC_21", "AC_63", "AC_40", "AC_50", "AC_15", "AC_44", "AC_45", "AC_53")
amacrine_GABAintersect_NaVClusters <- subset(x = amacrine_GABAintersect, idents = GABAintersect_NaVClusters)

DP_amacrine_GABAintersect_NaVClusters_GOI <- DotPlot(amacrine_GABAintersect_NaVClusters, features = GenesofInterest_filt, dot.scale=4, cluster.idents=TRUE, cols=c("yellow","blue")) + RotatedAxis() +theme(axis.text.x=element_text(size=6),axis.text.y=element_text(size=6),legend.key.size=unit(1,'cm'),legend.key.height=unit(0.5,'cm'),legend.key.width=unit(0.2,'cm'),legend.title=element_text(size=4),legend.text=element_text(size=4), axis.title=element_text(size=4)) #GABAintersect_NaVClusters_GOI_DotPlot.pdf
DP_amacrine_GABAintersect_NaVClusters_GOI$data


    #Keep major genes of interest
GenesofInterest_filt2 <- c("Scn1a", "Scn3a","Chrm1", "Chrna2", "Chrna3", "Chrna4", "Chrna5", "Chrna6", "Chrnb2", "Chrnb3", "Grm1", "Grm2", "Grm3", "Grm4", "Grm5", "Grm7", "Grm8", "Gria1", "Gria2", "Gria3", "Gria4", "Grid2", "Grin1", "Grin2a", "Grin2b", "Glra1", "Glra2", "Glra3", "Glrb", "Gabbr1", "Gabbr2", "Gabra1", "Gabra2", "Gabra3", "Gabrb1", "Gabrb3", "Gabrg2", "Gabrg3", "Gabrd")
DP_amacrine_GABAintersect_NaVClusters_filteredGOI <- DotPlot(amacrine_GABAintersect_NaVClusters, features = GenesofInterest_filt2, dot.scale=4, cluster.idents=TRUE, cols=c("yellow","blue")) + RotatedAxis() +theme(axis.text.x=element_text(size=6),axis.text.y=element_text(size=6),legend.key.size=unit(1,'cm'),legend.key.height=unit(0.5,'cm'),legend.key.width=unit(0.2,'cm'),legend.title=element_text(size=4),legend.text=element_text(size=4), axis.title=element_text(size=4)) #GABAintersect_NaVClusters_filteredGOI_DotPlot.pdf

    #Use cluster order from genes of interest above to add marker genes to dot plot
amacrine_GABAintersect_NaVClusters_filteredGOI_order <- c("AC_36", "AC_30", "AC_3", "AC_15", "AC_63", "AC_45", "AC_54", "AC_44", "AC_60", "AC_50", "AC_21", "AC_40", "AC_46", "AC_25", "AC_31", "AC_39", "AC_53", "AC_32", "AC_7", "AC_2")
amacrine_GABAintersect_NaVClusters@active.ident <- factor(amacrine_GABAintersect_NaVClusters@active.ident, levels=amacrine_GABAintersect_NaVClusters_filteredGOI_order)

markers <- c("Sst", "Penk", "Nos1", "Crh", "Cck", "Chat")

DP_amacrine_GABAintersect_NaVClusters_markers <- DotPlot(amacrine_GABAintersect_NaVClusters, features = markers, dot.scale=4, cluster.idents=FALSE, cols=c("yellow","blue")) + RotatedAxis() +theme(axis.text.x=element_text(size=6),axis.text.y=element_text(size=6),legend.key.size=unit(1,'cm'),legend.key.height=unit(0.5,'cm'),legend.key.width=unit(0.2,'cm'),legend.title=element_text(size=4),legend.text=element_text(size=4), axis.title=element_text(size=4)) #GABAintersect_NaVClusters_filteredGOIACOrder_MarkerGenes_DotPlot.pdf

    #Filter to retain expressed genes 
GenedsofInterest_filt2_plus_markers <- c("Chrm1", "Chrna2", "Chrna3", "Chrna4", "Chrna5", "Chrna6", "Chrnb2", "Chrnb3", "Grm1", "Grm2", "Grm3", "Grm4", "Grm5", "Grm7", "Grm8", "Gria1", "Gria2", "Gria3", "Gria4", "Grid2", "Grin1", "Grin2a", "Grin2b", "Glra1", "Glra2", "Glra3", "Glrb", "Gabbr1", "Gabbr2", "Gabra1", "Gabra2", "Gabra3", "Gabrb1", "Gabrb3", "Gabrg2", "Gabrg3", "Gabrd","Sst", "Penk", "Nos1", "Crh", "Cck", "Chat")
DP_amacrine_GABAintersect_NaVClusters_GOIplusmarkers <- DotPlot(amacrine_GABAintersect_NaVClusters, features = GenedsofInterest_filt2_plus_markers, dot.scale=4, cluster.idents=FALSE, cols=c("yellow","blue")) + RotatedAxis() +theme(axis.text.x=element_text(size=6),axis.text.y=element_text(size=6),legend.key.size=unit(1,'cm'),legend.key.height=unit(0.5,'cm'),legend.key.width=unit(0.2,'cm'),legend.title=element_text(size=4),legend.text=element_text(size=4), axis.title=element_text(size=4)) #GABAintersect_NaVClusters_FilteredGOIPlusMarkers_DP.pdf


#sessionInfo()
#R version 4.2.1 (2022-06-23)
#Platform: x86_64-apple-darwin17.0 (64-bit)
#Running under: macOS Big Sur 11.5

#Matrix products: default
#BLAS:   /Library/Frameworks/R.framework/Versions/4.2/Resources/lib/libRblas.0.dylib
#LAPACK: /Library/Frameworks/R.framework/Versions/4.2/Resources/lib/libRlapack.dylib

#locale:
#[1] en_US.UTF-8/en_US.UTF-8/en_US.UTF-8/C/en_US.UTF-8/en_US.UTF-8

#attached base packages:
#[1] grid      stats     graphics  grDevices utils     datasets  methods   base     

#other attached packages:
# [1] ComplexHeatmap_2.12.1 qs_0.25.5             viridis_0.6.3         viridisLite_0.4.2     lubridate_1.9.2       forcats_1.0.0         stringr_1.5.0         purrr_1.0.1           readr_2.1.4          
#[10] tidyr_1.3.0           tibble_3.2.1          tidyverse_2.0.0       ggplot2_3.4.2         patchwork_1.1.2       dplyr_1.1.2           scCustomize_1.1.2     SeuratObject_4.1.3    Seurat_4.3.0.1       

#loaded via a namespace (and not attached):
#  [1] circlize_0.4.15        plyr_1.8.8             igraph_1.5.0           lazyeval_0.2.2         sp_2.0-0               splines_4.2.1          RApiSerialize_0.1.2    listenv_0.9.0         
#  [9] scattermore_1.2        digest_0.6.33          foreach_1.5.2          htmltools_0.5.5        fansi_1.0.4            magrittr_2.0.3         tensor_1.5             paletteer_1.5.0       
# [17] cluster_2.1.4          doParallel_1.0.17      ROCR_1.0-11            tzdb_0.4.0             globals_0.16.2         RcppParallel_5.1.7     matrixStats_1.0.0      timechange_0.2.0      
# [25] spatstat.sparse_3.0-2  colorspace_2.1-0       ggrepel_0.9.3          crayon_1.5.2           jsonlite_1.8.7         progressr_0.13.0       spatstat.data_3.0-1    stringfish_0.15.8     
# [33] survival_3.5-5         zoo_1.8-12             iterators_1.0.14       glue_1.6.2             polyclip_1.10-4        gtable_0.3.3           leiden_0.4.3           GetoptLong_1.0.5      
# [41] future.apply_1.11.0    shape_1.4.6            BiocGenerics_0.42.0    abind_1.4-5            scales_1.2.1           spatstat.random_3.1-5  miniUI_0.1.1.1         Rcpp_1.0.11           
# [49] xtable_1.8-4           clue_0.3-64            reticulate_1.30        stats4_4.2.1           htmlwidgets_1.6.2      httr_1.4.6             RColorBrewer_1.1-3     ellipsis_0.3.2        
# [57] ica_1.0-3              pkgconfig_2.0.3        uwot_0.1.16            deldir_1.0-9           utf8_1.2.3             janitor_2.2.0          tidyselect_1.2.0       rlang_1.1.1           
# [65] reshape2_1.4.4         later_1.3.1            munsell_0.5.0          tools_4.2.1            cli_3.6.1              ggprism_1.0.4          generics_0.1.3         ggridges_0.5.4        
# [73] fastmap_1.1.1          goftest_1.2-3          rematch2_2.1.2         fitdistrplus_1.1-11    RANN_2.6.1             pbapply_1.7-2          future_1.33.0          nlme_3.1-162          
# [81] mime_0.12              ggrastr_1.0.2          compiler_4.2.1         beeswarm_0.4.0         plotly_4.10.2          png_0.1-8              spatstat.utils_3.0-3   stringi_1.7.12        
# [89] lattice_0.21-8         Matrix_1.5-1           vctrs_0.6.3            pillar_1.9.0           lifecycle_1.0.3        spatstat.geom_3.2-2    lmtest_0.9-40          GlobalOptions_0.1.2   
# [97] RcppAnnoy_0.0.21       data.table_1.14.8      cowplot_1.1.1          irlba_2.3.5.1          httpuv_1.6.11          R6_2.5.1               promises_1.2.0.1       KernSmooth_2.23-22    
#[105] gridExtra_2.3          vipor_0.4.5            IRanges_2.30.1         parallelly_1.36.0      codetools_0.2-19       MASS_7.3-60            rjson_0.2.21           withr_2.5.0           
#[113] sctransform_0.3.5      S4Vectors_0.34.0       parallel_4.2.1         hms_1.1.3              snakecase_0.11.0       Rtsne_0.16             spatstat.explore_3.2-1 shiny_1.7.4.1         
#[121] ggbeeswarm_0.7.2      

