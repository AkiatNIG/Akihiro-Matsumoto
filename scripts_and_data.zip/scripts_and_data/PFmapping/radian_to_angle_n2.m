function [outputArg1,outputArg2] = radian_to_angle_n2(num)
%UNTITLED2 Summary of this function goes here
%   num=[cos,sin]

%
%
ang0=num(1)/sqrt(num(1)^2+num(2)^2);
ang_deg=acos(ang0)*(180/pi);
%
%
if num(1)>=0&&num(2)>=0;%area1
    ang_deg9=ang_deg;
elseif num(1)<0&&num(2)>=0;%area2
    ang_deg9=ang_deg;
elseif num(1)<0&&num(2)<0;%area3
    ang_deg9=ang_deg+(180-ang_deg)*2;
elseif num(1)>=0&&num(2)<0;%area4
    ang_deg9=360-ang_deg;
end
    


outputArg1 = ang_deg9;
%outputArg2 = ang_deg9;
end

