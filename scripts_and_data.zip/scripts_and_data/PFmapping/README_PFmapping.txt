1. System requirements
The codes are available on Matlab (2017b or later) and R (4.3.2) on Windows11.
All the codes were tested on the above systems.
Those codes do not need non-standard hardware.

2. Installation guide
Copy the codes on the basic Matlab path on your system. And load dset.mat, demo dataset for Matlab, on Workspace. Then run the scripts. There are instructions on the header parts of the individual scripts.
out_rois.mat: information of RFs and release site location relative to RF center. output of mapping_rois_onRF.m.
w1.mat: density map. output of densitymap_rois.m.
radian_to_angle_n2.m and make_density_mtx_forPD_n2.m are files for visualization and are referred by show_RF_PF_n2.m. Please copy these two files to Matlab path.
Typical install time on a "normal" desktop computer would be ~5 minutes.

3. Demo
3-1. load dset.mat
3-2. run mapping_rois_onRF.m by using dset.mat.
3-3. you will get an image of mapped rois on RFs, and an output including mapped roi information. This file will be used by show_RF_PF_n2.m.
3-4. run densitymap_rois.m by using dset.m. Then you will get an output of density map information.
3-5. run show_RF_PF_n2.m to display PF and RF by using a file of mapped roi information (output of mapping_rois_onRF.m) and a file of density map information (output of densitymap_rois.m).
Expected run time for demo on a "normal" desktop computer would be ~5 minutes.

4. Instructions for use
load dset.mat on Matlab workspace and run each script from Command window. This process does not need any non-standard procedure for Matlab.
Reproduction instructions are shown in Extended Data Figure 6. The users can reproduce release site mapping, density map, and PF and RF by using those scripts. Based on the mapped release site angles relative to center (RF center), users can reproduce polarhistogram of orientation of release sites. Overlap index can be computed by using mapped PF and RF. The orientational tuning of individual groups can be computed from the density map (detailed instruction is shown in Extended Data Figure 6d). 
 