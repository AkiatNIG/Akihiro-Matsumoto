function [outputArg1,outputArg2] = untitled(dsi, pd, ds, fig_flg, flip_flg)
%visualize matrix data
%   

%
if fig_flg==1;
    close all;
end
rng=0.8;
%
lg=length(dsi);
%
mtx0=zeros(ds,ds);
d_ax=linspace(-1,1,ds);
%
%pars=[0,0,0,0];
for i=1:lg;
    if flip_flg==1;
        jpd=angle_flip(pd(i));
    else
        jpd=pd(i);
    end
    ad0=[cosd(jpd),sind(jpd)]*dsi(i);
    %
    [val,id_x]=min(abs(d_ax-ad0(1)));
    [val,id_y]=min(abs(-1*d_ax-ad0(2)));
    %
    mtx0(id_y,id_x)=mtx0(id_y,id_x)+1;
    %
    if i==1;
        pars=[ad0,id_x,id_y,jpd];
    else
        pars=[pars;[ad0,id_x,id_y,jpd]];
    end
end
%
if fig_flg==1;
    figure('position',[150,300,500,300]);
    subplot(1,2,1);
    imagesc(mtx0);hold on
    axis square;
    colormap('jet');
    contour(mtx0,7);
    %
    dt=[0:1:360];
    subplot(1,2,2);
    plot(cosd(dt)*(ds/2)*rng+ds/2+0.5,sind(dt)*(ds/2)*rng+ds/2+0.5,'-','linewidth',1.5,'color',[0.3,0.3,0.3]);hold on
    contour(mtx0,6,'linewidth',0.8);
    axis square;
    set(gca,'ticklength',[0;0]);
    set(gca,'ydir','reverse');
end
%


    


outputArg1 = mtx0;
outputArg2 = pars;
end

