function [outputArg1,outputArg2] = show_RF_PF(out_rois, w1)
%Visualize RF and PF
%input variables, out_tois and w1 are from mapping_rois_onRF and
%densitymap_rois, respectively.


all_rfs=out_rois{1,1};
[k,av]=convhull(all_rfs);
%
ptt=out_rois{2,1};
%
%%Thresholding rois based on density map
ymx=max(ptt(:,1));
ymi=min(ptt(:,1));
xmx=max(ptt(:,2));
xmi=min(ptt(:,2));
w1b=imresize(w1,[ymx-ymi,xmx-xmi]);
disp([ymx-ymi,ymx-ymi]);
w1b=flipud(w1b);
w1b=fliplr(w1b);
%
es_ptt=ptt;
ptt=ptt+[(ymx-ymi)/2,(ymx-ymi)/2];
plot(ptt(:,2),ptt(:,1),'wo');
%
ptt2=[ptt,zeros(length(ptt(:,1)),1)];
for i=1:length(ptt(:,1));
    disp([round(ptt(i,1)),round(ptt(i,2))]);
    if round(ptt(i,1))<=0||round(ptt(i,2))<=0
        v0=0;
    else
        v0=w1b(round(ptt(i,1)),round(ptt(i,2)));
    end
    ptt2(i,1:2)=ptt(i,:);
    ptt2(i,3)=v0;
end
th=mean2(w1b)+std2(w1b)*1.25;
fid=find(ptt2(:,3)>th);
ptt3=ptt2(fid,:);
ptt3b=es_ptt(fid,:);
%
%%
pRF=[all_rfs(k,1),all_rfs(k,2)];
pRF_ps=polyshape(pRF(:,2),pRF(:,1));
pf9=ptt3b;
[k2,av2]=convhull(pf9);
pPF=[pf9(k2,1),pf9(k2,2)];
pPF_ps=polyshape(pPF(:,2),pPF(:,1));
%
figure('position',[450,300,300,200]);
plot(pRF_ps,'linewidth',1,'edgecolor',[200,0,185]/255,'facecolor',[200,0,185]/255,'facealpha',0.5,'edgealpha',0.7);hold on
plot(pPF_ps,'linewidth',1,'edgecolor',[0,200,230]/255,'facecolor',[0,200,230]/255,'facealpha',0.5,'edgealpha',0.7);hold on
plot(mean(pRF(:,2)),mean(pRF(:,1)),'o','markersize',5,'markeredgecolor','none','markerfacecolor',[200,0,185]/255);
plot(mean(pPF(:,2)),mean(pPF(:,1)),'o','markersize',5,'markeredgecolor','none','markerfacecolor',[0,200,230]/255);
axis image;


%outputArg1 = inputArg1;
%outputArg2 = inputArg2;
end

