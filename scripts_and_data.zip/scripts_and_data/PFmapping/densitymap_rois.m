function [outputArg1,outputArg2] = densitymap_rois(dset)
%make density map of roi locations relative to RF center
%   

for i=1:length(dset(:,1));
    b0=dset{i,2};
    if i==1;
        ptt=dset{i,3};
        b9=b0;
    else
        ptt=[ptt;dset{i,3}];
        b9=[b9;b0];
    end
end
%
es2=[ptt(:,2),ptt(:,1),ptt(:,1)*0,ptt(:,1)*0];
for i=1:length(es2(:,1));
    ang0=radian_to_angle_n2(es2(i,1:2));
    es2(i,3)=ang0;
    %
    d0=sqrt(es2(i,1)^2+es2(i,2)^2);
    es2(i,4)=d0;
end
[val,mid]=max(es2(:,4));
d9=es2(:,4)/val;
es2=[es2,d9];
pf0b2=es2;
%
[k,av]=convhull(b9);
df=15;
des=[b9(k,2),b9(k,1)];
des2=des;
for i=1:length(des(:,1));
    r0=(des(1)^2+des(2)^2)/((sqrt(des(1)^2+des(2)^2)/val)^2);
    des2(i,:)=des(i,:)/sqrt(r0)+df/2;
end
des2=[des2(:,2),des2(:,1)];
ttt=[ptt,es2(:,3:5)];
[w1,w2]=make_density_mtx_forPD_n2(ttt(:,5),ttt(:,3),df,0,0);
figure('position',[250,300,300,200]);
imagesc(w1);hold on
%set(gca,'ydir','normal');
axis image;
%
%%



outputArg1 = w1;
%outputArg2 = inputArg2;
end

