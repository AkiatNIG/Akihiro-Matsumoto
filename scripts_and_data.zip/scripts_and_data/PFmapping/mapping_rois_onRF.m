function [outputArg1,outputArg2] = mapping_rois_onRF(dset)
%Map the release site locations relative to individual RF centers
%dset: demo dataset
%column1: RFs
%column2: RFs for processing
%column3: location of release sites

%
for i=1:length(dset(:,1));
    b0=dset{i,2};
    if i==1;
        b9=b0;
    else
        b9=[b9;b0];
    end
end
%
figure('position',[150,300,300,200]);
for i=1:length(dset(:,1));
    ku2=dset{i,1};
    ku2=polyshape(ku2(:,2),ku2(:,1));
    plot(ku2,'linewidth',1,'edgecolor',[200,0,185]/255,'facecolor',[200,0,185]/255,'facealpha',0.2,'edgealpha',0.5);hold on
    %
    if i==1;
        ptt=dset{i,3};
    else
        ptt=[ptt;dset{i,3}];
    end
end
%
pth1=mean(b9(:,1))+std(b9(:,1))*2;
pth2=mean(b9(:,2))+std(b9(:,2))*2;
gid1=find(abs(b9(:,1))>pth1);
gid2=find(abs(b9(:,2))>pth2);
%
all_rfs=b9;
all_rfs(gid1,1)=-9999;
all_rfs(gid2,2)=-9999;
fid=find(all_rfs(:,1)~=-9999&all_rfs(:,2)~=-9999);
all_rfs=all_rfs(fid,:);
%
[k,av]=convhull(all_rfs);
plot(ptt(:,2),ptt(:,1),'o','markersize',4,'markerfacecolor',[0,200,230]/255,'markeredgecolor','w');hold on
plot(all_rfs(k,2),all_rfs(k,1),'-k','linewidth',1.2);
axis image;
%
%%
out_rois=cell(1,1);
out_rois{1,1}=all_rfs;
out_rois{2,1}=ptt;


outputArg1 = out_rois;
%outputArg2 = inputArg2;
end

